package com.example.taskmanagerapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

public class CreateEditTask extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {

    private EditText et_title, et_description;
    private TextView title;
    private Button btn_pick, btnAddTaskToDb;
    private DBHelper dbHelper;
    private SQLiteDatabase database;
    private String pickedDate = "", pickedTime = "";
    private String[] d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_edit_task);
        et_title = findViewById(R.id.et_title);
        et_description = findViewById(R.id.et_description);
        btn_pick = findViewById(R.id.buttonPickDateTime);
        btnAddTaskToDb = findViewById(R.id.btnAddTaskToDb);
        title = findViewById(R.id.test);
        dbHelper = new DBHelper(this);
        database = dbHelper.getWritableDatabase();
        Intent intent = getIntent();
        d = intent.getStringArrayExtra("data");
        if(d != null) {
            title.setText("Editing Task: " + d[0]);
            et_title.setText(d[1]);
            et_description.setText(d[2]);
            btnAddTaskToDb.setText("Update");
        } else {
            d = null;
        }
        btn_pick.setOnClickListener(v -> {
            Calendar now = Calendar.getInstance();
            DatePickerDialog dpd = DatePickerDialog.newInstance(
                    CreateEditTask.this,
                    now.get(Calendar.YEAR),
                    now.get(Calendar.MONTH),
                    now.get(Calendar.DAY_OF_MONTH)
            );
            TimePickerDialog tpd = TimePickerDialog.newInstance(CreateEditTask.this, true);
            dpd.show(getSupportFragmentManager(), "Datepickerdialog");
            tpd.show(getSupportFragmentManager(), "Timepickerdialog");
        });
        btnAddTaskToDb.setOnClickListener(v -> {
            addDataToDB(d);
        });
    }

    private void addDataToDB(String[] d) {
        if(et_title.getText().toString().isEmpty() || et_description.getText().toString().isEmpty()) {
            if(d == null && (pickedDate.isEmpty() || pickedTime.isEmpty())) {
                Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        ContentValues values = new ContentValues();
        if(d == null) {
            values.put("title", et_title.getText().toString());
            values.put("description", et_description.getText().toString());
            values.put("dueDate", pickedDate + " - " + pickedTime);
            database.insert("my_table", null, values);
            Toast.makeText(this, "Task has been added successfully", Toast.LENGTH_SHORT).show();
        }else {
            values.put("title", et_title.getText().toString());
            values.put("description", et_description.getText().toString());
            values.put("dueDate", d[3]);
            database.update("my_table", values, "id = ?", new String[]{String.valueOf(d[0])});
            Toast.makeText(this, "Task has been updated successfully", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        pickedDate = dayOfMonth+"/"+(monthOfYear+1)+"/"+year;
    }

    @Override
    public void onTimeSet(TimePickerDialog view, int hourOfDay, int minute, int second) {
        pickedTime = hourOfDay+"h"+minute+"m"+second;
    }
}


package com.example.taskmanagerapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mydatabase.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_QUERY =
                "CREATE TABLE my_table (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "title TEXT, " +
                        "description TEXT, " +
                        "dueDate TEXT)";
        db.execSQL(CREATE_TABLE_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS my_table");
        onCreate(db);
    }
}

package com.example.taskmanagerapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv;
    private TaskAdapter adapter;
    private List<String[]> dataList;
    private DBHelper dbHelper;
    private SQLiteDatabase database;

    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        dbHelper = new DBHelper(this);
        database = dbHelper.getWritableDatabase();
        swipeRefreshLayout = findViewById(R.id.main);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if(id == R.id.action_main) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                    return true;
                }
                if (id == R.id.action_back) {
                    finish();
                    return true;
                }
                return false;
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                getAllDataSortedByNameDesc();
                swipeRefreshLayout.setRefreshing(false);
            }
        });
        findViewById(R.id.btn_add_task).setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateEditTask.class);
            startActivity(intent);
        });
        rv = findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(this));
        dataList = new ArrayList<>();

        adapter = new TaskAdapter(this, dataList);
        getAllDataSortedByNameDesc();
    }

    public void getAllDataSortedByNameDesc() {
        dataList.clear();
        Cursor cursor = database.query(
                "my_table",
                null,
                null,
                null,
                null,
                null,
                "dueDate DESC"
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getLong(cursor.getColumnIndex("id")));
                String title = cursor.getString(cursor.getColumnIndex("title"));
                String description = cursor.getString(cursor.getColumnIndex("description"));
                String dueDate = cursor.getString(cursor.getColumnIndex("dueDate"));
                dataList.add(new String[]{id, title, description, dueDate});
            } while (cursor.moveToNext());
            cursor.close();
        }
        rv.setAdapter(adapter);
    }
}

package com.example.taskmanagerapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.MyViewHolder> {
    private static List<String[]> dataList;
    private static Context context;


    public TaskAdapter(Context context, List<String[]> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        String[] data = dataList.get(position);
        holder.textView.setText(data[1]);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;

        public MyViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_task_name);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(context, ViewTask.class);
                    i.putExtra("data", dataList.get(getAdapterPosition()));
                    context.startActivity(i);
                }
            });
        }
    }
}


package com.example.taskmanagerapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewTask extends AppCompatActivity {

    private TextView tv_title, tv_description, tv_due_date;
    private ImageView edit, delete;

    private DBHelper dbHelper;
    private SQLiteDatabase database;
    String[] d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_task);
        Intent intent = getIntent();
        d = intent.getStringArrayExtra("data");
        dbHelper = new DBHelper(this);
        database = dbHelper.getWritableDatabase();
        tv_title = findViewById(R.id.tv_title);
        tv_description = findViewById(R.id.tv_description);
        tv_due_date = findViewById(R.id.tv_due_date);
        edit = findViewById(R.id.edit);
        delete = findViewById(R.id.delete);

        tv_title.setText("Title: " + d[1]);
        tv_description.setText("Description: " + d[2]);
        tv_due_date.setText("Due on: " + d[3]);

        edit.setOnClickListener(v -> {
            Intent i = new Intent(this, CreateEditTask.class);
            i.putExtra("data", d);
            startActivity(i);
        });

        delete.setOnClickListener(v -> {
            database.delete("my_table", "id = ?", new String[]{String.valueOf(d[0])});
            Toast.makeText(this, "Task Deleted Successfully", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}